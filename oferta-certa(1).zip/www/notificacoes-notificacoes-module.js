(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["notificacoes-notificacoes-module"],{

/***/ "./src/app/notificacoes/notificacoes.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/notificacoes/notificacoes.module.ts ***!
  \*****************************************************/
/*! exports provided: NotificacoesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacoesPageModule", function() { return NotificacoesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _notificacoes_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./notificacoes.page */ "./src/app/notificacoes/notificacoes.page.ts");







var routes = [
    {
        path: '',
        component: _notificacoes_page__WEBPACK_IMPORTED_MODULE_6__["NotificacoesPage"]
    }
];
var NotificacoesPageModule = /** @class */ (function () {
    function NotificacoesPageModule() {
    }
    NotificacoesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_notificacoes_page__WEBPACK_IMPORTED_MODULE_6__["NotificacoesPage"]]
        })
    ], NotificacoesPageModule);
    return NotificacoesPageModule;
}());



/***/ }),

/***/ "./src/app/notificacoes/notificacoes.page.html":
/*!*****************************************************!*\
  !*** ./src/app/notificacoes/notificacoes.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"headerTop\">\n\t<ion-toolbar>\n\t\t<img src=\"assets/logo-ofeta.png\">\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content>\n\t<ion-grid>\n\t\t<ion-row>\n\t\t\t<ion-col size=\"12\">\n\t\t\t\t<ion-icon src=\"assets/svg/web-maintenance.svg\"></ion-icon>\n\t\t\t\t<h2>Em construção . . .</h2>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</ion-grid>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/notificacoes/notificacoes.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/notificacoes/notificacoes.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-content ion-grid {\n  height: 100%; }\n  :host ion-content ion-grid ion-row {\n    height: 100%;\n    display: flex;\n    align-items: center; }\n  :host ion-content ion-grid ion-row ion-col ion-icon {\n      width: 100%;\n      font-size: 150px;\n      color: #560d8a; }\n  :host ion-content ion-grid ion-row ion-col h2 {\n      text-align: center;\n      color: #5a0e8f;\n      font-weight: bold; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbm90aWZpY2Fjb2VzL0M6XFxQcm9qZXRvc1xcb2ZlcnRhLWNlcnRhL3NyY1xcYXBwXFxub3RpZmljYWNvZXNcXG5vdGlmaWNhY29lcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFHTSxZQUFZLEVBQUE7RUFIbEI7SUFLUSxZQUFZO0lBQ1osYUFBYTtJQUNiLG1CQUFtQixFQUFBO0VBUDNCO01BVVksV0FBVztNQUNYLGdCQUFnQjtNQUNoQixjQUFjLEVBQUE7RUFaMUI7TUFlWSxrQkFBa0I7TUFDbEIsY0FBYztNQUNkLGlCQUFpQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvbm90aWZpY2Fjb2VzL25vdGlmaWNhY29lcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XHJcbiAgaW9uLWNvbnRlbnQge1xyXG4gICAgaW9uLWdyaWQge1xyXG4gICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgIGlvbi1yb3cge1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE1MHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogIzU2MGQ4YTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGgyIHtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBjb2xvcjogIzVhMGU4ZjtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/notificacoes/notificacoes.page.ts":
/*!***************************************************!*\
  !*** ./src/app/notificacoes/notificacoes.page.ts ***!
  \***************************************************/
/*! exports provided: NotificacoesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacoesPage", function() { return NotificacoesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var NotificacoesPage = /** @class */ (function () {
    function NotificacoesPage() {
    }
    NotificacoesPage.prototype.ngOnInit = function () {
    };
    NotificacoesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-notificacoes',
            template: __webpack_require__(/*! ./notificacoes.page.html */ "./src/app/notificacoes/notificacoes.page.html"),
            styles: [__webpack_require__(/*! ./notificacoes.page.scss */ "./src/app/notificacoes/notificacoes.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], NotificacoesPage);
    return NotificacoesPage;
}());



/***/ })

}]);
//# sourceMappingURL=notificacoes-notificacoes-module.js.map