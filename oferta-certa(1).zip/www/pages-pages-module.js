(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-pages-module"],{

/***/ "./src/app/pages/pages.module.ts":
/*!***************************************!*\
  !*** ./src/app/pages/pages.module.ts ***!
  \***************************************/
/*! exports provided: PagesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesPageModule", function() { return PagesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages.page */ "./src/app/pages/pages.page.ts");
/* harmony import */ var src_theme_theme_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/theme/theme.module */ "./src/theme/theme.module.ts");





var routes = [
    {
        path: "",
        component: _pages_page__WEBPACK_IMPORTED_MODULE_3__["PagesPage"],
        children: [
            { path: "", loadChildren: "./home/home.module#HomePageModule" },
            {
                path: "home",
                loadChildren: "./home/home.module#HomePageModule"
            },
            {
                path: "notificacoes",
                loadChildren: "../notificacoes/notificacoes.module#NotificacoesPageModule"
            },
            { path: "menu", loadChildren: "../menu/menu.module#MenuPageModule" },
            { path: "**", redirectTo: "home", pathMatch: "full" }
        ]
    },
    {
        path: "",
        redirectTo: "pages"
    }
];
var PagesPageModule = /** @class */ (function () {
    function PagesPageModule() {
    }
    PagesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [src_theme_theme_module__WEBPACK_IMPORTED_MODULE_4__["ThemeModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            declarations: [_pages_page__WEBPACK_IMPORTED_MODULE_3__["PagesPage"]]
        })
    ], PagesPageModule);
    return PagesPageModule;
}());



/***/ }),

/***/ "./src/app/pages/pages.page.html":
/*!***************************************!*\
  !*** ./src/app/pages/pages.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-tabs #app_tabs contentId=\"content\">\r\n\t<ion-tab-bar slot=\"bottom\">\r\n\t\t<ion-tab-button tab=\"home\">\r\n\t\t\t<ion-icon src=\"assets/svg/shopping-cart.svg\">></ion-icon>\r\n\t\t\t<!-- <ion-label>Home</ion-label> -->\r\n\t\t\t<ion-badge>12</ion-badge>\r\n\t\t</ion-tab-button>\r\n\r\n\t\t<ion-tab-button tab=\"notificacoes\">\r\n\t\t\t<ion-icon src=\"assets/svg/shop.svg\"></ion-icon>\r\n\t\t\t<!-- <ion-badge>5</ion-badge> -->\r\n\t\t\t<!-- <ion-label>Depoimentos</ion-label> -->\r\n\t\t</ion-tab-button>\r\n\r\n\t\t<ion-tab-button tab=\"notificacoes\">\r\n\t\t\t<ion-icon src=\"assets/svg/map.svg\"></ion-icon>\r\n\t\t\t<!-- <ion-badge>2</ion-badge> -->\r\n\t\t\t<!-- <ion-label>Ajuda</ion-label> -->\r\n\t\t</ion-tab-button>\r\n\r\n\t\t<ion-tab-button tab=\"notificacoes\">\r\n\t\t\t<ion-icon src=\"assets/svg/notification.svg\"></ion-icon>\r\n\t\t\t<!-- <ion-badge>3</ion-badge> -->\r\n\t\t\t<!-- <ion-label>Advogadas</ion-label> -->\r\n\t\t</ion-tab-button>\r\n\r\n\t\t<ion-tab-button tab=\"menu\">\r\n\t\t\t<ion-icon src=\"assets/svg/menu.svg\"></ion-icon>\r\n\t\t\t<!-- <ion-label>Menu</ion-label> -->\r\n\t\t</ion-tab-button>\r\n\t</ion-tab-bar>\r\n</ion-tabs>\r\n"

/***/ }),

/***/ "./src/app/pages/pages.page.scss":
/*!***************************************!*\
  !*** ./src/app/pages/pages.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-icon {\n  width: 100%;\n  padding: 5px; }\n\nion-tab-button {\n  --color: #666; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvQzpcXFByb2pldG9zXFxvZmVydGEtY2VydGEvc3JjXFxhcHBcXHBhZ2VzXFxwYWdlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFXO0VBQ1gsWUFBWSxFQUFBOztBQUdkO0VBQ0UsYUFBUSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcGFnZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWljb24ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDVweDtcclxufVxyXG5cclxuaW9uLXRhYi1idXR0b24ge1xyXG4gIC0tY29sb3I6ICM2NjY7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/pages.page.ts":
/*!*************************************!*\
  !*** ./src/app/pages/pages.page.ts ***!
  \*************************************/
/*! exports provided: PagesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesPage", function() { return PagesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var PagesPage = /** @class */ (function () {
    function PagesPage(menu, navigation) {
        this.menu = menu;
        this.navigation = navigation;
    }
    PagesPage.prototype.ngOnInit = function () {
        // this.tabRef.select("home");
        this.tabRef.select("home");
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("app_tabs"),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonTabs"])
    ], PagesPage.prototype, "tabRef", void 0);
    PagesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-pages",
            template: __webpack_require__(/*! ./pages.page.html */ "./src/app/pages/pages.page.html"),
            styles: [__webpack_require__(/*! ./pages.page.scss */ "./src/app/pages/pages.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], PagesPage);
    return PagesPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-pages-module.js.map