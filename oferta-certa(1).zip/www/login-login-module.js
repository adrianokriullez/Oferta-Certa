(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");
/* harmony import */ var src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/theme/theme.module */ "./src/theme/theme.module.ts");








var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__["ThemeModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.html":
/*!***************************************!*\
  !*** ./src/app/login/login.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"headerTop\">\r\n\t<ion-toolbar>\r\n\t\t<ion-back-button text=\"\" [icon]=\"'arrow-back'\"></ion-back-button>\r\n\t\t<ion-title>Login</ion-title>\r\n\t</ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\t<ion-grid>\r\n\t\t<ion-row>\r\n\t\t\t<ion-col size=\"12\">\r\n\t\t\t\t<form novalidate [formGroup]=\"loginForm\" (ngSubmit)=\"submitLogin()\">\r\n\t\t\t\t\t<ion-list>\r\n\t\t\t\t\t\t<ion-item>\r\n\t\t\t\t\t\t\t<ion-label position=\"floating\">Email</ion-label>\r\n\t\t\t\t\t\t\t<ion-input\r\n\t\t\t\t\t\t\t\ttype=\"email\"\r\n\t\t\t\t\t\t\t\tformControlName=\"email\"\r\n\t\t\t\t\t\t\t></ion-input>\r\n\t\t\t\t\t\t</ion-item>\r\n\r\n\t\t\t\t\t\t<div\r\n\t\t\t\t\t\t\tclass=\"warning-msg\"\r\n\t\t\t\t\t\t\t*ngIf=\"!loginForm.controls.email.valid && submitted\"\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t<span>Digite um e-mail válido</span>\r\n\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t<ion-item>\r\n\t\t\t\t\t\t\t<ion-label position=\"floating\">Senha</ion-label>\r\n\t\t\t\t\t\t\t<ion-input\r\n\t\t\t\t\t\t\t\ttype=\"{{password}}\"\r\n\t\t\t\t\t\t\t\tformControlName=\"password\"\r\n\t\t\t\t\t\t\t></ion-input>\r\n\t\t\t\t\t\t\t<ion-icon\r\n\t\t\t\t\t\t\t\tname=\"{{iconeye}}\"\r\n\t\t\t\t\t\t\t\t(click)=\"eyeTroca($event)\"\r\n\t\t\t\t\t\t\t></ion-icon>\r\n\t\t\t\t\t\t</ion-item>\r\n\r\n\t\t\t\t\t\t<div\r\n\t\t\t\t\t\t\tclass=\"warning-msg\"\r\n\t\t\t\t\t\t\t*ngIf=\"!loginForm.controls.password.valid && submitted\"\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t<span>A senha deve ter entre 6 e 20 caracteres</span>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</ion-list>\r\n\r\n\t\t\t\t\t<div>\r\n\t\t\t\t\t\t<ion-button\r\n\t\t\t\t\t\t\ttype=\"submit\"\r\n\t\t\t\t\t\t\tcolor=\"primary\"\r\n\t\t\t\t\t\t\tshape=\"round\"\r\n\t\t\t\t\t\t\tclass=\"btn-actions\"\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\tEntrar\r\n\t\t\t\t\t\t</ion-button>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</form>\r\n\t\t\t</ion-col>\r\n\t\t</ion-row>\r\n\t</ion-grid>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  font-family: \"quicksand-regular\"; }\n  ion-content ion-grid {\n    height: 100%; }\n  ion-content ion-grid ion-row {\n      height: 100%;\n      display: flex;\n      align-items: center; }\n  ion-content form ion-button {\n    width: 100%; }\n  ion-content form ion-list {\n    background-color: transparent;\n    padding: 0px !important;\n    margin-bottom: 32px; }\n  ion-content form ion-list ion-label {\n      color: #808080; }\n  ion-content form ion-list ion-icon {\n      position: absolute;\n      color: #808080;\n      right: 0px;\n      bottom: 0px;\n      margin-bottom: 8px;\n      margin-right: 10px;\n      z-index: 10; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vQzpcXFByb2pldG9zXFxvZmVydGEtY2VydGEvc3JjXFxhcHBcXGxvZ2luXFxsb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxnQ0FBZ0MsRUFBQTtFQURqQztJQUdFLFlBQVksRUFBQTtFQUhkO01BTUcsWUFBWTtNQUNaLGFBQWE7TUFDYixtQkFBbUIsRUFBQTtFQVJ0QjtJQWNHLFdBQVcsRUFBQTtFQWRkO0lBa0JHLDZCQUE2QjtJQUM3Qix1QkFBdUI7SUFDdkIsbUJBQW1CLEVBQUE7RUFwQnRCO01Bc0JJLGNBQWMsRUFBQTtFQXRCbEI7TUF5Qkksa0JBQWtCO01BQ2xCLGNBQWM7TUFDZCxVQUFVO01BQ1YsV0FBVztNQUNYLGtCQUFrQjtNQUNsQixrQkFBa0I7TUFDbEIsV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG5cdGZvbnQtZmFtaWx5OiBcInF1aWNrc2FuZC1yZWd1bGFyXCI7XHJcblx0aW9uLWdyaWQge1xyXG5cdFx0aGVpZ2h0OiAxMDAlO1xyXG5cclxuXHRcdGlvbi1yb3cge1xyXG5cdFx0XHRoZWlnaHQ6IDEwMCU7XHJcblx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRmb3JtIHtcclxuXHRcdGlvbi1idXR0b24ge1xyXG5cdFx0XHR3aWR0aDogMTAwJTtcclxuXHRcdH1cclxuXHJcblx0XHRpb24tbGlzdCB7XHJcblx0XHRcdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdFx0XHRwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogMzJweDtcclxuXHRcdFx0aW9uLWxhYmVsIHtcclxuXHRcdFx0XHRjb2xvcjogIzgwODA4MDtcclxuXHRcdFx0fVxyXG5cdFx0XHRpb24taWNvbiB7XHJcblx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdGNvbG9yOiAjODA4MDgwO1xyXG5cdFx0XHRcdHJpZ2h0OiAwcHg7XHJcblx0XHRcdFx0Ym90dG9tOiAwcHg7XHJcblx0XHRcdFx0bWFyZ2luLWJvdHRvbTogOHB4O1xyXG5cdFx0XHRcdG1hcmdpbi1yaWdodDogMTBweDtcclxuXHRcdFx0XHR6LWluZGV4OiAxMDtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/auth/index.js");
/* harmony import */ var src_services_storage_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/services/storage-provider */ "./src/services/storage-provider.ts");






//Firebase


var LoginPage = /** @class */ (function () {
    function LoginPage(formbuilder, afAuth, navigation, alertController, loading, storage) {
        this.formbuilder = formbuilder;
        this.afAuth = afAuth;
        this.navigation = navigation;
        this.alertController = alertController;
        this.loading = loading;
        this.storage = storage;
        //submit do form
        this.submitted = false;
        //Mostra a senha do inout
        this.iconeye = "eye";
        //type do campo de senha
        this.password = "password";
        this.loginForm = this.formbuilder.group({
            email: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]],
            password: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6)]]
        });
    }
    LoginPage.prototype.ngOnInit = function () { };
    //Login
    LoginPage.prototype.submitLogin = function () {
        var _this = this;
        this.submitted = true;
        if (this.loginForm.valid) {
            this.loading.create({ message: "Aguarde..." }).then(function (_loading) {
                _loading.present();
            });
            this.afAuth.auth
                .signInWithEmailAndPassword(this.loginForm.value.email, this.loginForm.value.password)
                .then(function (_response) {
                var userInfo = {
                    id: _response.user.uid,
                    email: _response.user.email
                };
                _this.storage.setItem("user", userInfo);
                console.log("TCL: LoginPage -> submitLogin -> _response", _response);
                //Enviar o usuário para próxima página
                _this.navigation.navigateRoot("/pages", { animated: true });
                //finaliza o loading
                _this.loading.dismiss();
                _this.submitted = false;
            })
                .catch(function (error) {
                if (error.code == "auth/wrong-password") {
                    _this.showAlert("Erro ao logar", "Senha incorreta", "Voltar");
                    _this.loginForm.controls["password"].setValue(null);
                    //finaliza o loading
                    _this.loading.dismiss();
                    _this.submitted = false;
                }
                else {
                    _this.showAlert("Erro ao logar", "Não foi possivel realizar seu login", "Voltar");
                    _this.loginForm.controls["password"].setValue(null);
                    //finaliza o loading
                    _this.loading.dismiss();
                    _this.submitted = false;
                }
            });
        }
    };
    //Mostra senha para o usuário
    LoginPage.prototype.eyeTroca = function (event) {
        if (event.target.name == "eye") {
            this.iconeye = "eye-off";
            this.password = "text";
        }
        else {
            this.iconeye = "eye";
            this.password = "password";
        }
    };
    //Alert para mensagens
    LoginPage.prototype.showAlert = function (title, msg, btn) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            subHeader: title,
                            message: msg,
                            buttons: [btn]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-login",
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__["AngularFireAuth"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            src_services_storage_provider__WEBPACK_IMPORTED_MODULE_5__["StorageProvider"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map