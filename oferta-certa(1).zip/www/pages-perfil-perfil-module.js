(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-perfil-perfil-module"],{

/***/ "./src/app/pages/perfil/perfil.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/perfil/perfil.module.ts ***!
  \***********************************************/
/*! exports provided: PerfilPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerfilPageModule", function() { return PerfilPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _perfil_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./perfil.page */ "./src/app/pages/perfil/perfil.page.ts");
/* harmony import */ var src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/theme/theme.module */ "./src/theme/theme.module.ts");








var routes = [
    {
        path: '',
        component: _perfil_page__WEBPACK_IMPORTED_MODULE_6__["PerfilPage"]
    }
];
var PerfilPageModule = /** @class */ (function () {
    function PerfilPageModule() {
    }
    PerfilPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__["ThemeModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_perfil_page__WEBPACK_IMPORTED_MODULE_6__["PerfilPage"]]
        })
    ], PerfilPageModule);
    return PerfilPageModule;
}());



/***/ }),

/***/ "./src/app/pages/perfil/perfil.page.html":
/*!***********************************************!*\
  !*** ./src/app/pages/perfil/perfil.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"headerTop\">\n\t<ion-toolbar>\n\t\t<ion-back-button text=\"\" [icon]=\"'arrow-back'\"></ion-back-button>\n\t\t<img src=\"assets/logo-ofeta.png\">\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content>\n\t<ion-grid>\n\t\t<ion-row>\n\t\t\t<ion-col size=\"12\">\n\t\t\t\t<h2>Editar dados do Usuario</h2>\n\t\t\t</ion-col>\n\t\t\t<ion-col size=\"12\">\n\t\t\t\t<form novalidate [formGroup]=\"loginForm\" (ngSubmit)=\"submitLogin()\">\n\t\t\t\t\t<ion-list>\n\t\t\t\t\t\t<ion-item>\n\t\t\t\t\t\t\t<ion-label position=\"floating\">Email</ion-label>\n\t\t\t\t\t\t\t<ion-input\n\t\t\t\t\t\t\t\ttype=\"email\"\n\t\t\t\t\t\t\t\tformControlName=\"email\"\n\t\t\t\t\t\t\t></ion-input>\n\t\t\t\t\t\t</ion-item>\n\n\t\t\t\t\t\t<div\n\t\t\t\t\t\t\tclass=\"warning-msg\"\n\t\t\t\t\t\t\t*ngIf=\"!loginForm.controls.email.valid && submitted\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t<span>Digite um e-mail válido</span>\n\t\t\t\t\t\t</div>\n\n\t\t\t\t\t\t<ion-item>\n\t\t\t\t\t\t\t<ion-label position=\"floating\">Senha</ion-label>\n\t\t\t\t\t\t\t<ion-input\n\t\t\t\t\t\t\t\ttype=\"{{password}}\"\n\t\t\t\t\t\t\t\tformControlName=\"password\"\n\t\t\t\t\t\t\t></ion-input>\n\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\tname=\"{{iconeye}}\"\n\t\t\t\t\t\t\t\t(click)=\"eyeTroca($event)\"\n\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t</ion-item>\n\n\t\t\t\t\t\t<div\n\t\t\t\t\t\t\tclass=\"warning-msg\"\n\t\t\t\t\t\t\t*ngIf=\"!loginForm.controls.password.valid && submitted\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t<span>A senha deve ter entre 6 e 20 caracteres</span>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</ion-list>\n\n\t\t\t\t\t<div>\n\t\t\t\t\t\t<ion-button\n\t\t\t\t\t\t\ttype=\"submit\"\n\t\t\t\t\t\t\tcolor=\"secondary\"\n\t\t\t\t\t\t\tshape=\"round\"\n\t\t\t\t\t\t\tclass=\"btn-actions\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\tSalvar\n\t\t\t\t\t\t</ion-button>\n\t\t\t\t\t</div>\n\t\t\t\t</form>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</ion-grid>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/perfil/perfil.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/perfil/perfil.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  font-family: \"quicksand-regular\"; }\n  ion-content ion-grid {\n    height: 100%; }\n  ion-content form ion-button {\n    width: 100%; }\n  ion-content form ion-list {\n    background-color: transparent;\n    padding: 0px !important;\n    margin-bottom: 32px; }\n  ion-content form ion-list ion-label {\n      color: #808080; }\n  ion-content form ion-list ion-icon {\n      position: absolute;\n      color: #808080;\n      right: 0px;\n      bottom: 0px;\n      margin-bottom: 8px;\n      margin-right: 10px;\n      z-index: 10; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGVyZmlsL0M6XFxQcm9qZXRvc1xcb2ZlcnRhLWNlcnRhL3NyY1xcYXBwXFxwYWdlc1xccGVyZmlsXFxwZXJmaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsZ0NBQWdDLEVBQUE7RUFEakM7SUFHRSxZQUFZLEVBQUE7RUFIZDtJQVlHLFdBQVcsRUFBQTtFQVpkO0lBZ0JHLDZCQUE2QjtJQUM3Qix1QkFBdUI7SUFDdkIsbUJBQW1CLEVBQUE7RUFsQnRCO01Bb0JJLGNBQWMsRUFBQTtFQXBCbEI7TUF1Qkksa0JBQWtCO01BQ2xCLGNBQWM7TUFDZCxVQUFVO01BQ1YsV0FBVztNQUNYLGtCQUFrQjtNQUNsQixrQkFBa0I7TUFDbEIsV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcGVyZmlsL3BlcmZpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcblx0Zm9udC1mYW1pbHk6IFwicXVpY2tzYW5kLXJlZ3VsYXJcIjtcclxuXHRpb24tZ3JpZCB7XHJcblx0XHRoZWlnaHQ6IDEwMCU7XHJcblxyXG5cdFx0aW9uLXJvdyB7XHJcblxyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0Zm9ybSB7XHJcblx0XHRpb24tYnV0dG9uIHtcclxuXHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHR9XHJcblxyXG5cdFx0aW9uLWxpc3Qge1xyXG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRcdFx0cGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDMycHg7XHJcblx0XHRcdGlvbi1sYWJlbCB7XHJcblx0XHRcdFx0Y29sb3I6ICM4MDgwODA7XHJcblx0XHRcdH1cclxuXHRcdFx0aW9uLWljb24ge1xyXG5cdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHRjb2xvcjogIzgwODA4MDtcclxuXHRcdFx0XHRyaWdodDogMHB4O1xyXG5cdFx0XHRcdGJvdHRvbTogMHB4O1xyXG5cdFx0XHRcdG1hcmdpbi1ib3R0b206IDhweDtcclxuXHRcdFx0XHRtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcblx0XHRcdFx0ei1pbmRleDogMTA7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/pages/perfil/perfil.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/perfil/perfil.page.ts ***!
  \*********************************************/
/*! exports provided: PerfilPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PerfilPage", function() { return PerfilPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_services_storage_provider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/storage-provider */ "./src/services/storage-provider.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/auth/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");






var PerfilPage = /** @class */ (function () {
    function PerfilPage(formbuilder, afAuth, navigation, alertController, loading, storage) {
        this.formbuilder = formbuilder;
        this.afAuth = afAuth;
        this.navigation = navigation;
        this.alertController = alertController;
        this.loading = loading;
        this.storage = storage;
        //submit do form
        this.submitted = false;
        //Mostra a senha do inout
        this.iconeye = "eye";
        //type do campo de senha
        this.password = "password";
        this.loginForm = this.formbuilder.group({
            email: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email]],
            password: ''
        });
    }
    PerfilPage.prototype.ngOnInit = function () {
        this.buscaDados();
    };
    PerfilPage.prototype.buscaDados = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var retorno;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.storage.getItem("user")];
                    case 1:
                        retorno = _a.sent();
                        this.loginForm.setValue({
                            email: retorno.email || '',
                            password: '',
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    //Login
    PerfilPage.prototype.submitLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var userInfo, alert_1, alert_2;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.submitted = true;
                        if (!this.loginForm.valid) return [3 /*break*/, 3];
                        userInfo = {
                            email: this.loginForm.value.email
                        };
                        return [4 /*yield*/, this.storage.setItem("user", userInfo)];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.alertController.create({
                                message: 'Dados salvos!',
                                buttons: ['Ok']
                            })];
                    case 2:
                        alert_1 = _a.sent();
                        alert_1.present();
                        //finaliza o loading
                        this.submitted = false;
                        return [3 /*break*/, 5];
                    case 3: return [4 /*yield*/, this.alertController.create({
                            subHeader: 'Atenção',
                            message: 'Verifique os dados',
                            buttons: ['Ok']
                        })];
                    case 4:
                        alert_2 = _a.sent();
                        alert_2.present();
                        _a.label = 5;
                    case 5: return [2 /*return*/];
                }
            });
        });
    };
    //Mostra senha para o usuário
    PerfilPage.prototype.eyeTroca = function (event) {
        if (event.target.name == "eye") {
            this.iconeye = "eye-off";
            this.password = "text";
        }
        else {
            this.iconeye = "eye";
            this.password = "password";
        }
    };
    //Alert para mensagens
    PerfilPage.prototype.showAlert = function (title, msg, btn) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            subHeader: title,
                            message: msg,
                            buttons: [btn]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PerfilPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-perfil',
            template: __webpack_require__(/*! ./perfil.page.html */ "./src/app/pages/perfil/perfil.page.html"),
            styles: [__webpack_require__(/*! ./perfil.page.scss */ "./src/app/pages/perfil/perfil.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__["AngularFireAuth"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            src_services_storage_provider__WEBPACK_IMPORTED_MODULE_2__["StorageProvider"]])
    ], PerfilPage);
    return PerfilPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-perfil-perfil-module.js.map