(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cadastro-cadastro-module"],{

/***/ "./src/app/cadastro/cadastro.module.ts":
/*!*********************************************!*\
  !*** ./src/app/cadastro/cadastro.module.ts ***!
  \*********************************************/
/*! exports provided: CadastroPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CadastroPageModule", function() { return CadastroPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _cadastro_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cadastro.page */ "./src/app/cadastro/cadastro.page.ts");
/* harmony import */ var src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/theme/theme.module */ "./src/theme/theme.module.ts");








var routes = [
    {
        path: '',
        component: _cadastro_page__WEBPACK_IMPORTED_MODULE_6__["CadastroPage"]
    }
];
var CadastroPageModule = /** @class */ (function () {
    function CadastroPageModule() {
    }
    CadastroPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__["ThemeModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_cadastro_page__WEBPACK_IMPORTED_MODULE_6__["CadastroPage"]]
        })
    ], CadastroPageModule);
    return CadastroPageModule;
}());



/***/ }),

/***/ "./src/app/cadastro/cadastro.page.html":
/*!*********************************************!*\
  !*** ./src/app/cadastro/cadastro.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"headerTop\">\r\n\t<ion-toolbar>\r\n\t\t<ion-back-button text=\"\" [icon]=\"'arrow-back'\"></ion-back-button>\r\n\t\t<ion-title>Cadastro</ion-title>\r\n\t</ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\t<ion-grid>\r\n\t\t<ion-row>\r\n\t\t\t<ion-col size=\"12\">\r\n\t\t\t\t<form\r\n\t\t\t\t\tnovalidate\r\n\t\t\t\t\t[formGroup]=\"registerOne\"\r\n\t\t\t\t\t(ngSubmit)=\"submitRegisterOne()\"\r\n\t\t\t\t>\r\n\t\t\t\t\t<ion-list>\r\n\t\t\t\t\t\t<ion-item>\r\n\t\t\t\t\t\t\t<ion-label position=\"floating\">Email</ion-label>\r\n\t\t\t\t\t\t\t<ion-input\r\n\t\t\t\t\t\t\t\ttype=\"email\"\r\n\t\t\t\t\t\t\t\tformControlName=\"email\"\r\n\t\t\t\t\t\t\t></ion-input>\r\n\t\t\t\t\t\t</ion-item>\r\n\r\n\t\t\t\t\t\t<div\r\n\t\t\t\t\t\t\tclass=\"warning-msg\"\r\n\t\t\t\t\t\t\t*ngIf=\"\r\n\t\t\t\t\t\t\t\t!registerOne.controls.email.valid && submitted\r\n\t\t\t\t\t\t\t\"\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t<span>Digite um e-mail válido</span>\r\n\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t<ion-item>\r\n\t\t\t\t\t\t\t<ion-label position=\"floating\">Crie uma senha</ion-label>\r\n\t\t\t\t\t\t\t<ion-input\r\n\t\t\t\t\t\t\t\ttype=\"{{ password }}\"\r\n\t\t\t\t\t\t\t\tformControlName=\"password\"\r\n\t\t\t\t\t\t\t></ion-input>\r\n\t\t\t\t\t\t\t<ion-icon\r\n\t\t\t\t\t\t\t\tname=\"{{ iconeye }}\"\r\n\t\t\t\t\t\t\t\t(click)=\"eyeTroca($event)\"\r\n\t\t\t\t\t\t\t></ion-icon>\r\n\t\t\t\t\t\t</ion-item>\r\n\r\n\t\t\t\t\t\t<div\r\n\t\t\t\t\t\t\tclass=\"warning-msg\"\r\n\t\t\t\t\t\t\t*ngIf=\"\r\n\t\t\t\t\t\t\t\t!registerOne.controls.password.valid &&\r\n\t\t\t\t\t\t\t\tsubmitted\r\n\t\t\t\t\t\t\t\"\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t<span>A senha deve ter entre 6 e 20 caracteres</span>\r\n\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t<ion-item>\r\n\t\t\t\t\t\t\t<ion-label position=\"floating\"\r\n\t\t\t\t\t\t\t\t>Confirme sua senha</ion-label\r\n\t\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t<ion-input\r\n\t\t\t\t\t\t\t\ttype=\"{{ password }}\"\r\n\t\t\t\t\t\t\t\tformControlName=\"confirmpassword\"\r\n\t\t\t\t\t\t\t></ion-input>\r\n\t\t\t\t\t\t</ion-item>\r\n\r\n\t\t\t\t\t\t<div\r\n\t\t\t\t\t\t\tclass=\"warning-msg\"\r\n\t\t\t\t\t\t\t*ngIf=\"\r\n\t\t\t\t\t\t\t\tregisterOne.value.password !=\r\n\t\t\t\t\t\t\t\t\tregisterOne.value.confirmpassword &&\r\n\t\t\t\t\t\t\t\tsubmitted\r\n\t\t\t\t\t\t\t\"\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t<span>As senhas não coincidem</span>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</ion-list>\r\n\r\n\t\t\t\t\t<div text-right>\r\n\t\t\t\t\t\t<ion-button type=\"submit\" shape=\"round\" class=\"btn-actions\"\r\n\t\t\t\t\t\t\t>Salvar</ion-button\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</form>\r\n\t\t\t</ion-col>\r\n\t\t</ion-row>\r\n\t</ion-grid>\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/cadastro/cadastro.page.scss":
/*!*********************************************!*\
  !*** ./src/app/cadastro/cadastro.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  font-family: \"quicksand-regular\"; }\n  ion-content ion-grid {\n    height: 100%; }\n  ion-content form ion-list {\n    background-color: transparent;\n    padding: 0px !important;\n    margin-bottom: 32px; }\n  ion-content form ion-list ion-label {\n      color: #808080; }\n  ion-content form ion-list ion-icon {\n      position: absolute;\n      color: #808080;\n      right: 0px;\n      bottom: 0px;\n      margin-bottom: 8px;\n      margin-right: 10px;\n      z-index: 10; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FkYXN0cm8vQzpcXFByb2pldG9zXFxvZmVydGEtY2VydGEvc3JjXFxhcHBcXGNhZGFzdHJvXFxjYWRhc3Ryby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxnQ0FBZ0MsRUFBQTtFQURqQztJQUdHLFlBQVksRUFBQTtFQUhmO0lBUUcsNkJBQTZCO0lBQzdCLHVCQUF1QjtJQUN2QixtQkFBbUIsRUFBQTtFQVZ0QjtNQVlHLGNBQWMsRUFBQTtFQVpqQjtNQWVHLGtCQUFrQjtNQUNsQixjQUFjO01BQ2QsVUFBVTtNQUNWLFdBQVc7TUFDWCxrQkFBa0I7TUFDbEIsa0JBQWtCO01BQ2xCLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NhZGFzdHJvL2NhZGFzdHJvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuXHRmb250LWZhbWlseTogXCJxdWlja3NhbmQtcmVndWxhclwiO1xyXG5cdGlvbi1ncmlkIHtcclxuXHQgIGhlaWdodDogMTAwJTtcclxuXHR9XHJcblxyXG5cdGZvcm0ge1xyXG5cdCAgaW9uLWxpc3Qge1xyXG5cdFx0IGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdFx0IHBhZGRpbmc6IDBweCAhaW1wb3J0YW50O1xyXG5cdFx0IG1hcmdpbi1ib3R0b206IDMycHg7XHJcblx0XHQgaW9uLWxhYmVsIHtcclxuXHRcdFx0Y29sb3I6ICM4MDgwODA7XHJcblx0XHQgfVxyXG5cdFx0IGlvbi1pY29uIHtcclxuXHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRjb2xvcjogIzgwODA4MDtcclxuXHRcdFx0cmlnaHQ6IDBweDtcclxuXHRcdFx0Ym90dG9tOiAwcHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDhweDtcclxuXHRcdFx0bWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5cdFx0XHR6LWluZGV4OiAxMDtcclxuXHRcdCB9XHJcblx0ICB9XHJcblx0fVxyXG4gfVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/cadastro/cadastro.page.ts":
/*!*******************************************!*\
  !*** ./src/app/cadastro/cadastro.page.ts ***!
  \*******************************************/
/*! exports provided: CadastroPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CadastroPage", function() { return CadastroPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/auth/index.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(firebase_app__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! firebase/firestore */ "./node_modules/firebase/firestore/dist/index.esm.js");
/* harmony import */ var src_services_storage_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/services/storage-provider */ "./src/services/storage-provider.ts");




//Firebase






var CadastroPage = /** @class */ (function () {
    function CadastroPage(formbuilder, navigation, alertController, loading, afAuth, storage) {
        this.formbuilder = formbuilder;
        this.navigation = navigation;
        this.alertController = alertController;
        this.loading = loading;
        this.afAuth = afAuth;
        this.storage = storage;
        this.db = firebase_app__WEBPACK_IMPORTED_MODULE_5__["firestore"]();
        //Mostra a senha do inout
        this.iconeye = "eye";
        //type do campo de senha
        this.password = "password";
        //submit do form
        this.submitted = false;
        this.registerOne = this.formbuilder.group({
            email: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]],
            password: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6)]],
            confirmpassword: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(6)]]
        });
    }
    CadastroPage.prototype.ngOnInit = function () { };
    CadastroPage.prototype.submitRegisterOne = function () {
        var _this = this;
        this.submitted = true;
        if (this.registerOne.valid) {
            if (this.registerOne.value.password ===
                this.registerOne.value.confirmpassword) {
                this.loading.create({ message: "Aguarde..." }).then(function (_loading) {
                    _loading.present();
                });
                this.afAuth.auth
                    .createUserWithEmailAndPassword(this.registerOne.value.email, this.registerOne.value.password)
                    .then(function (_user) {
                    var userInfo = {
                        id: _this.afAuth.auth.currentUser.uid,
                        email: _this.registerOne.value.email,
                        date: firebase_app__WEBPACK_IMPORTED_MODULE_5__["firestore"].FieldValue.serverTimestamp()
                    };
                    _this.storage.setItem("user", userInfo);
                    console.log("TCL: CadastroPage -> submitRegisterOne -> userInfo", userInfo);
                    //Enviar o usuário para próxima página
                    _this.navigation.navigateForward("/pages", {
                        animated: true
                    });
                    //finaliza o loading
                    _this.loading.dismiss();
                    _this.submitted = false;
                })
                    .catch(function (error) {
                    if (error.code == "auth/email-already-in-use") {
                        _this.showAlert("Erro ao cadastrar", "O endereço de e-mail já está sendo usado por outra conta", "Voltar");
                        //finaliza o loading
                        _this.loading.dismiss();
                        _this.submitted = false;
                    }
                    else {
                        //Mensagem de Erro padrão caso não encontre o erro de firesabe
                        _this.showAlert("Erro ao cadastrar", "Não foi possível realizar seu cadastro", "Voltar");
                        //finaliza o loading
                        _this.loading.dismiss();
                        _this.submitted = false;
                    }
                });
            }
        }
    };
    //Mostra senha para o usuário
    CadastroPage.prototype.eyeTroca = function (event) {
        if (event.target.name == "eye") {
            this.iconeye = "eye-off";
            this.password = "text";
        }
        else {
            this.iconeye = "eye";
            this.password = "password";
        }
    };
    //Alert para mensagens
    CadastroPage.prototype.showAlert = function (title, msg, btn) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            subHeader: title,
                            message: msg,
                            buttons: [btn]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CadastroPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-cadastro",
            template: __webpack_require__(/*! ./cadastro.page.html */ "./src/app/cadastro/cadastro.page.html"),
            styles: [__webpack_require__(/*! ./cadastro.page.scss */ "./src/app/cadastro/cadastro.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_4__["AngularFireAuth"],
            src_services_storage_provider__WEBPACK_IMPORTED_MODULE_7__["StorageProvider"]])
    ], CadastroPage);
    return CadastroPage;
}());



/***/ })

}]);
//# sourceMappingURL=cadastro-cadastro-module.js.map