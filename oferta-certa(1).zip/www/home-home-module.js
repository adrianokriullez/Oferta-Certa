(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");
/* harmony import */ var src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/theme/theme.module */ "./src/theme/theme.module.ts");








var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                src_theme_theme_module__WEBPACK_IMPORTED_MODULE_7__["ThemeModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                    {
                        path: "",
                        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                    }
                ])
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/pages/home/home.page.html":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"headerTop\">\n\t<ion-toolbar>\n\t\t<img src=\"assets/logo-ofeta.png\">\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content>\n\t<ion-grid>\n\t\t<ion-row>\n\t\t\t<ion-col size=\"12\" text-center>\n\t\t\t\t<h2 class=\"title\">Produtos em Destaque!</h2>\n\t\t\t</ion-col>\n\t\t\t<ion-col\n\t\t\t\tsize=\"12\"\n\t\t\t\t*ngFor=\"let item of produtos\"\n\t\t\t\tstyle=\"margin-bottom: 10px;\"\n\t\t\t>\n\t\t\t\t<ion-card>\n\t\t\t\t\t<div\n\t\t\t\t\t\t[style.background-image]=\"'url(' + item.img + ')'\"\n\t\t\t\t\t\tclass=\"img-card\"\n\t\t\t\t\t\t(click)=\"openDetail(item)\"\n\t\t\t\t\t></div>\n\t\t\t\t\t<ion-card-header text-left (click)=\"openDetail(item)\">\n\t\t\t\t\t\t<ion-card-title\n\t\t\t\t\t\t\tcolor=\"secondary\"\n\t\t\t\t\t\t\tclass=\"descricao\"\n\t\t\t\t\t\t\tstyle=\"-webkit-box-orient: vertical!important\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t{{item.descricao}}\n\t\t\t\t\t\t</ion-card-title>\n\t\t\t\t\t</ion-card-header>\n\n\t\t\t\t\t<ion-card-content>\n\t\t\t\t\t\t<ion-list no-lines>\n\t\t\t\t\t\t\t<ion-item style=\"--border-color: white;\">\n\t\t\t\t\t\t\t\t<span slot=\"start\" class=\"mercado\"\n\t\t\t\t\t\t\t\t\t>{{item.mercado}}<br />\n\t\t\t\t\t\t\t\t\t{{item.km}}</span\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t<span class=\"antesValor\" slot=\"end\"\n\t\t\t\t\t\t\t\t\t>{{item.valor}}</span\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</ion-item>\n\t\t\t\t\t\t\t<ion-item style=\"--border-color: white;\">\n\t\t\t\t\t\t\t\t<span slot=\"start\">\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"heart-empty\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"!item.like\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClass': item.like}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"forca(item)\"\n\t\t\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"heart\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"item.like\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClass': item.like}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"forca(item)\"\n\t\t\t\t\t\t\t\t\t\t>1</ion-icon\n\t\t\t\t\t\t\t\t\t>\n\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"star-outline\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"!item.start\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClassStart': item.start}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"start(item)\"\n\t\t\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"star\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"item.start\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClassStart': item.start}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"start(item)\"\n\t\t\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t<span class=\"descontoValor\" slot=\"end\"\n\t\t\t\t\t\t\t\t\t>{{item.desconto}}</span\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</ion-item>\n\t\t\t\t\t\t</ion-list>\n\t\t\t\t\t</ion-card-content>\n\t\t\t\t</ion-card>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</ion-grid>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .headerTop {\n  background: #dadde1; }\n\n:host ion-content {\n  --background: #dadde1; }\n\n:host .title {\n  margin: 5px 0px;\n  padding: 0px;\n  font-weight: 600; }\n\n:host ion-card {\n  font-family: \"ubuntu-medium\";\n  background-color: #f5f5f5;\n  height: 100%;\n  width: 100%;\n  margin: 0px;\n  border-radius: 20px; }\n\n:host ion-card .img-card {\n    height: 150px;\n    width: 100%;\n    background-color: #fff;\n    background-size: contain;\n    background-repeat: no-repeat;\n    background-position: top center; }\n\n:host ion-card .descricao {\n    color: #6b6b6b;\n    font-weight: 400;\n    text-align: center; }\n\n:host ion-card .antesValor {\n    text-decoration: line-through;\n    color: #f90303;\n    font-size: 16px;\n    font-weight: 200;\n    margin: 0px;\n    padding: 0px; }\n\n:host ion-card .descontoValor {\n    color: #600c83;\n    font-size: 25px;\n    font-weight: bold;\n    margin: 0px;\n    padding: 0px; }\n\n:host ion-card .valor {\n    font-family: \"ubuntu-bold\";\n    margin: 0px;\n    overflow: hidden !important;\n    display: -webkit-box !important;\n    -webkit-line-clamp: 1 !important; }\n\n:host ion-card .mercado {\n    font-size: 14px;\n    color: #444950;\n    margin-left: 5px; }\n\n:host ion-card ion-card-header {\n    padding: 0px;\n    margin: 10px 5px; }\n\n:host ion-card ion-card-header ion-card-title {\n      font-size: 16px;\n      font-weight: 500; }\n\n:host ion-card ion-card-content {\n    padding: 0px 5px 5px !important; }\n\n:host ion-card ion-icon {\n    font-size: 25px; }\n\n:host .cssClass {\n  color: red; }\n\n:host .cssClassStart {\n  color: #540d88; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9DOlxcUHJvamV0b3NcXG9mZXJ0YS1jZXJ0YS9zcmNcXGFwcFxccGFnZXNcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksbUJBQW1CLEVBQUE7O0FBRnZCO0VBS0kscUJBQWEsRUFBQTs7QUFMakI7RUFRSSxlQUFlO0VBQ2YsWUFBWTtFQUNaLGdCQUFnQixFQUFBOztBQVZwQjtFQWNJLDRCQUE0QjtFQUM1Qix5QkFBeUI7RUFDekIsWUFBWTtFQUNaLFdBQVc7RUFDWCxXQUFXO0VBQ1gsbUJBQW1CLEVBQUE7O0FBbkJ2QjtJQXFCTSxhQUFhO0lBQ2IsV0FBVztJQUNYLHNCQUFzQjtJQUN0Qix3QkFBd0I7SUFDeEIsNEJBQTRCO0lBQzVCLCtCQUErQixFQUFBOztBQTFCckM7SUErQk0sY0FBYztJQUNkLGdCQUFnQjtJQUNoQixrQkFBa0IsRUFBQTs7QUFqQ3hCO0lBcUNNLDZCQUE2QjtJQUM3QixjQUFjO0lBQ2QsZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixXQUFXO0lBQ1gsWUFBWSxFQUFBOztBQTFDbEI7SUE4Q00sY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsV0FBVztJQUNYLFlBQVksRUFBQTs7QUFsRGxCO0lBc0RNLDBCQUEwQjtJQUMxQixXQUFXO0lBQ1gsMkJBQTJCO0lBQzNCLCtCQUErQjtJQUMvQixnQ0FBZ0MsRUFDTzs7QUEzRDdDO0lBK0RNLGVBQWU7SUFDZixjQUFjO0lBQ2QsZ0JBQWdCLEVBQUE7O0FBakV0QjtJQXFFTSxZQUFZO0lBQ1osZ0JBQWdCLEVBQUE7O0FBdEV0QjtNQXdFUSxlQUFlO01BQ2YsZ0JBQWdCLEVBQUE7O0FBekV4QjtJQThFTSwrQkFBK0IsRUFBQTs7QUE5RXJDO0lBaUZNLGVBQWUsRUFBQTs7QUFqRnJCO0VBcUZJLFVBQVUsRUFBQTs7QUFyRmQ7RUF3RkksY0FBYyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgLmhlYWRlclRvcCB7XG4gICAgYmFja2dyb3VuZDogI2RhZGRlMTtcbiAgfVxuICBpb24tY29udGVudCB7XG4gICAgLS1iYWNrZ3JvdW5kOiAjZGFkZGUxO1xuICB9XG4gIC50aXRsZSB7XG4gICAgbWFyZ2luOiA1cHggMHB4O1xuICAgIHBhZGRpbmc6IDBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICB9XG5cbiAgaW9uLWNhcmQge1xuICAgIGZvbnQtZmFtaWx5OiBcInVidW50dS1tZWRpdW1cIjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW46IDBweDtcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICAgIC5pbWctY2FyZCB7XG4gICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xuICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcCBjZW50ZXI7XG4gICAgfVxuXG4gICAgLmRlc2NyaWNhbyB7XG4gICAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsICFpbXBvcnRhbnQ7XG4gICAgICBjb2xvcjogIzZiNmI2YjtcbiAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuXG4gICAgLmFudGVzVmFsb3Ige1xuICAgICAgdGV4dC1kZWNvcmF0aW9uOiBsaW5lLXRocm91Z2g7XG4gICAgICBjb2xvcjogI2Y5MDMwMztcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiAyMDA7XG4gICAgICBtYXJnaW46IDBweDtcbiAgICAgIHBhZGRpbmc6IDBweDtcbiAgICB9XG5cbiAgICAuZGVzY29udG9WYWxvciB7XG4gICAgICBjb2xvcjogIzYwMGM4MztcbiAgICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICBwYWRkaW5nOiAwcHg7XG4gICAgfVxuXG4gICAgLnZhbG9yIHtcbiAgICAgIGZvbnQtZmFtaWx5OiBcInVidW50dS1ib2xkXCI7XG4gICAgICBtYXJnaW46IDBweDtcbiAgICAgIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcbiAgICAgIGRpc3BsYXk6IC13ZWJraXQtYm94ICFpbXBvcnRhbnQ7XG4gICAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDEgIWltcG9ydGFudDtcbiAgICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWwgIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAubWVyY2FkbyB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBjb2xvcjogIzQ0NDk1MDtcbiAgICAgIG1hcmdpbi1sZWZ0OiA1cHg7XG4gICAgfVxuXG4gICAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICAgIHBhZGRpbmc6IDBweDtcbiAgICAgIG1hcmdpbjogMTBweCA1cHg7XG4gICAgICBpb24tY2FyZC10aXRsZSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpb24tY2FyZC1jb250ZW50IHtcbiAgICAgIHBhZGRpbmc6IDBweCA1cHggNXB4ICFpbXBvcnRhbnQ7XG4gICAgfVxuICAgIGlvbi1pY29uIHtcbiAgICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgICB9XG4gIH1cbiAgLmNzc0NsYXNzIHtcbiAgICBjb2xvcjogcmVkO1xuICB9XG4gIC5jc3NDbGFzc1N0YXJ0IHtcbiAgICBjb2xvcjogIzU0MGQ4ODtcbiAgfVxufVxuIl19 */"

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/firestore */ "./node_modules/firebase/firestore/dist/index.esm.js");
/* harmony import */ var src_services_storage_provider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/services/storage-provider */ "./src/services/storage-provider.ts");
/* harmony import */ var src_services_controle_produtos_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/services/controle-produtos.service */ "./src/services/controle-produtos.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






var HomePage = /** @class */ (function () {
    function HomePage(navCtrl, storage, controleProdutosService) {
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.controleProdutosService = controleProdutosService;
        this.image = "/assets/images/default-image.png";
        this.produtos = [
            {
                descricao: "Kit 12 Mini Biscoito Arroz Integral Chia Linhaça Camil 150g",
                valor: "R$150,00",
                desconto: "R$117,00",
                img: "https://www.extra-imagens.com.br/Alimentos/alimentosbasicos/arroz/14428677/1064540006/kit-12-mini-biscoito-arroz-integral-chia-linhaca-camil-150g-14428677.jpg",
                mercado: "Teixeira Supermercados",
                km: "5km",
                like: false,
                start: false
            },
            {
                descricao: "Fralda Pampers Confort Sec Super XG - 174 Unidades",
                valor: "R$191,70",
                desconto: "R$164,70",
                img: "https://www.extra-imagens.com.br/bebes/TrocadoBebe/FraldasDescartaveisparaBebes/1000069015/1012436201/fralda-pampers-confort-sec-super-xg-174-unidades-1000069015.jpg",
                mercado: "Colina Supermercados",
                km: "5km",
                like: false,
                start: false
            },
            {
                descricao: "Café Melitta a Vácuo Tradicional 500grs - Melitta",
                valor: "R$11,55",
                desconto: "R$7,99",
                img: "https://www.extra-imagens.com.br/Alimentos/Matinais/cafes/15093509/1120303447/cafe-melitta-a-vacuo-tradicional-500grs-melitta-15093509.jpg",
                mercado: "Chimar Supermercados",
                km: "5km",
                like: false,
                start: false
            },
            {
                descricao: "Café Pilão Almofada 500 Gramas",
                valor: "R$8,99",
                desconto: "R$5,99",
                img: "https://www.extra-imagens.com.br/Alimentos/Matinais/cafes/6574328/284144054/Cafe-Pilao-Almofada-500-Gramas-6574328.jpg",
                mercado: "Olidel Supermercados",
                km: "5km",
                like: false,
                start: false
            },
            {
                descricao: "Shampoo Pantene Força e Reconstrução 400ml",
                valor: "R$16,98",
                desconto: "R$95,99",
                img: "https://www.extra-imagens.com.br/perfumaria/produtosparacabelos/ShampoosparaCabelos/13776997/1203192835/shampoo-pantene-forca-e-reconstrucao-400ml-13776997.jpg",
                mercado: "Olidel Supermercados",
                km: "5km",
                like: false,
                start: false
            },
            {
                descricao: "Cerveja Budweiser Pilsen 330ml",
                valor: "R$ 2,58",
                desconto: "R$ 2,19",
                img: "https://i.promobit.com.br/855314610315603013367512294537.png",
                mercado: "Chimar Supermercados",
                km: "5km",
                like: false,
                start: false
            },
            {
                descricao: 'Smartphone Samsung Galaxy A10 32GB Dual Chip 2GB RAM Tela 6.2"',
                valor: "R$ 999,00 ",
                desconto: "R$ 679,03",
                img: "https://i.promobit.com.br/664802533015602865658695206277.jpg",
                mercado: "Supermercado Colina",
                km: "15km",
                like: false,
                start: false
            },
            {
                descricao: "Caixa Organizadora com Tampa em MDF 2 Peças Rosa e Vermelho Zippy Toys 6173",
                valor: "R$ 89,90",
                desconto: "R$ 39,90",
                img: "https://i.promobit.com.br/756388451415602998232595347394.jpg",
                mercado: "Chimar Supermercados",
                km: "16km",
                like: false,
                start: false
            },
            {
                descricao: 'Smartphone Motorola Moto G7 Power 32GB Dual Chip 3GB RAM Tela 6.2"',
                valor: "R$ 999,00",
                desconto: "R$ 849,15",
                img: "https://i.promobit.com.br/smartphone_motorola_moto_g7_power_32gb.jpg",
                mercado: "Supermercado Colina",
                km: "14km",
                like: false,
                start: false
            }
        ];
        this.retorno = this.storage.getItem("user");
    }
    HomePage.prototype.ngOnInit = function () { };
    //Detalhes do produto
    HomePage.prototype.openDetail = function (event) {
        //Passa o produto para o service de detalhes do produto
        this.controleProdutosService.selectedProduct = event;
        //Redireciona para página de produtos
        this.navCtrl.navigateForward("/produtos-detalhes", {
            animated: true
        });
    };
    HomePage.prototype.forca = function (item) {
        item.like = !item.like;
        this.produtos.indexOf(item);
    };
    HomePage.prototype.start = function (item) {
        item.start = !item.start;
        this.produtos.indexOf(item);
    };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-home",
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/pages/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"],
            src_services_storage_provider__WEBPACK_IMPORTED_MODULE_3__["StorageProvider"],
            src_services_controle_produtos_service__WEBPACK_IMPORTED_MODULE_4__["ControleProdutosService"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map