(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-produtos-detalhes-produtos-detalhes-module"],{

/***/ "./src/app/pages/produtos-detalhes/produtos-detalhes.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/produtos-detalhes/produtos-detalhes.module.ts ***!
  \*********************************************************************/
/*! exports provided: ProdutosDetalhesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProdutosDetalhesPageModule", function() { return ProdutosDetalhesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _produtos_detalhes_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./produtos-detalhes.page */ "./src/app/pages/produtos-detalhes/produtos-detalhes.page.ts");







var routes = [
    {
        path: '',
        component: _produtos_detalhes_page__WEBPACK_IMPORTED_MODULE_6__["ProdutosDetalhesPage"]
    }
];
var ProdutosDetalhesPageModule = /** @class */ (function () {
    function ProdutosDetalhesPageModule() {
    }
    ProdutosDetalhesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_produtos_detalhes_page__WEBPACK_IMPORTED_MODULE_6__["ProdutosDetalhesPage"]]
        })
    ], ProdutosDetalhesPageModule);
    return ProdutosDetalhesPageModule;
}());



/***/ }),

/***/ "./src/app/pages/produtos-detalhes/produtos-detalhes.page.html":
/*!*********************************************************************!*\
  !*** ./src/app/pages/produtos-detalhes/produtos-detalhes.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header class=\"headerTop\">\n\t<ion-toolbar>\n\t\t<ion-back-button text=\"\" [icon]=\"'arrow-back'\"></ion-back-button>\n\t\t<img src=\"assets/logo-ofeta.png\">\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content>\n\t<ion-grid>\n\t\t<ion-row>\n\t\t\t<ion-col size=\"12\">\n\t\t\t\t<!-- <ion-card>\n\t\t\t\t\t<div\n\t\t\t\t\t\t[style.background-image]=\"'url(' + produtos.img + ')'\"\n\t\t\t\t\t\tclass=\"img-card\"\n\t\t\t\t\t\t(click)=\"openDetail()\"\n\t\t\t\t\t></div>\n\t\t\t\t\t<ion-card-header text-left (click)=\"openDetail()\">\n\t\t\t\t\t\t<ion-card-title\n\t\t\t\t\t\t\tcolor=\"secondary\"\n\t\t\t\t\t\t\tclass=\"descricao\"\n\t\t\t\t\t\t\tstyle=\"-webkit-box-orient: vertical!important\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t{{ produtos.descricao }}\n\t\t\t\t\t\t</ion-card-title>\n\t\t\t\t\t</ion-card-header>\n\n\t\t\t\t\t<ion-card-content>\n\t\t\t\t\t\t<ion-item>\n\t\t\t\t\t\t\t<span class=\"antesValor\" slot=\"start\"\n\t\t\t\t\t\t\t\t>{{ produtos.valor }}</span\n\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t<span slot=\"end\">{{ produtos.km }}</span>\n\t\t\t\t\t\t</ion-item>\n\t\t\t\t\t\t<ion-item>\n\t\t\t\t\t\t\t<span class=\"descontoValor\" slot=\"start\"\n\t\t\t\t\t\t\t\t>{{ produtos.desconto }}</span\n\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t<span slot=\"end\">{{ produtos.mercado }}</span>\n\t\t\t\t\t\t</ion-item>\n\t\t\t\t\t</ion-card-content>\n\t\t\t\t</ion-card> -->\n\t\t\t\t<ion-card>\n\t\t\t\t\t<div\n\t\t\t\t\t\t[style.background-image]=\"'url(' + produtos.img + ')'\"\n\t\t\t\t\t\tclass=\"img-card\"\n\t\t\t\t\t></div>\n\t\t\t\t\t<ion-card-header text-left>\n\t\t\t\t\t\t<ion-card-title\n\t\t\t\t\t\t\tcolor=\"secondary\"\n\t\t\t\t\t\t\tclass=\"descricao\"\n\t\t\t\t\t\t\tstyle=\"-webkit-box-orient: vertical!important\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t{{produtos.descricao}}\n\t\t\t\t\t\t</ion-card-title>\n\t\t\t\t\t</ion-card-header>\n\n\t\t\t\t\t<ion-card-content>\n\t\t\t\t\t\t<ion-list no-lines>\n\t\t\t\t\t\t\t<ion-item style=\"--border-color: white;\">\n\t\t\t\t\t\t\t\t<span slot=\"start\" class=\"mercado\"\n\t\t\t\t\t\t\t\t\t>{{produtos.mercado}}<br />\n\t\t\t\t\t\t\t\t\t{{produtos.km}}</span\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t<span class=\"antesValor\" slot=\"end\"\n\t\t\t\t\t\t\t\t\t>{{produtos.valor}}</span\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</ion-item>\n\t\t\t\t\t\t\t<ion-item style=\"--border-color: white;\">\n\t\t\t\t\t\t\t\t<span slot=\"start\">\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"heart-empty\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"!produtos.like\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClass': produtos.like}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"forca(produtos)\"\n\t\t\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"heart\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"produtos.like\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClass': produtos.like}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"forca(produtos)\"\n\t\t\t\t\t\t\t\t\t\t>1</ion-icon\n\t\t\t\t\t\t\t\t\t>\n\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"star-outline\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"!produtos.start\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClassStart': produtos.start}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"start(produtos)\"\n\t\t\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t\t\t\t<ion-icon\n\t\t\t\t\t\t\t\t\t\tname=\"star\"\n\t\t\t\t\t\t\t\t\t\t*ngIf=\"produtos.start\"\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{'cssClassStart': produtos.start}\"\n\t\t\t\t\t\t\t\t\t\t(click)=\"start(produtos)\"\n\t\t\t\t\t\t\t\t\t></ion-icon>\n\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t<span class=\"descontoValor\" slot=\"end\"\n\t\t\t\t\t\t\t\t\t>{{produtos.desconto}}</span\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t</ion-item>\n\t\t\t\t\t\t</ion-list>\n\t\t\t\t\t</ion-card-content>\n\t\t\t\t</ion-card>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</ion-grid>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/produtos-detalhes/produtos-detalhes.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/pages/produtos-detalhes/produtos-detalhes.page.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .headerTop {\n  background: #dadde1; }\n\n:host ion-content {\n  --background: #dadde1; }\n\n:host ion-content ion-card {\n    font-family: \"ubuntu-medium\";\n    background-color: #f5f5f5;\n    height: 100%;\n    width: 100%;\n    margin: 0px;\n    border-radius: 20px; }\n\n:host ion-content ion-card .img-card {\n      height: 150px;\n      width: 100%;\n      background-color: #fff;\n      background-size: contain;\n      background-repeat: no-repeat;\n      background-position: top center; }\n\n:host ion-content ion-card .descricao {\n      color: #6b6b6b;\n      font-weight: 400;\n      text-align: center; }\n\n:host ion-content ion-card .antesValor {\n      text-decoration: line-through;\n      color: #f90303;\n      font-size: 16px;\n      font-weight: 200;\n      margin: 0px;\n      padding: 0px; }\n\n:host ion-content ion-card .descontoValor {\n      color: #600c83;\n      font-size: 25px;\n      font-weight: bold;\n      margin: 0px;\n      padding: 0px; }\n\n:host ion-content ion-card .valor {\n      font-family: \"ubuntu-bold\";\n      margin: 0px;\n      overflow: hidden !important;\n      display: -webkit-box !important;\n      -webkit-line-clamp: 1 !important; }\n\n:host ion-content ion-card .mercado {\n      font-size: 14px;\n      color: #444950;\n      margin-left: 5px; }\n\n:host ion-content ion-card ion-card-header {\n      padding: 0px;\n      margin: 10px 5px; }\n\n:host ion-content ion-card ion-card-header ion-card-title {\n        font-size: 16px;\n        font-weight: 500; }\n\n:host ion-content ion-card ion-card-content {\n      padding: 0px 5px 5px !important; }\n\n:host ion-content ion-card ion-icon {\n      font-size: 25px; }\n\n:host ion-content .cssClass {\n    color: red; }\n\n:host ion-content .cssClassStart {\n    color: #540d88; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcHJvZHV0b3MtZGV0YWxoZXMvQzpcXFByb2pldG9zXFxvZmVydGEtY2VydGEvc3JjXFxhcHBcXHBhZ2VzXFxwcm9kdXRvcy1kZXRhbGhlc1xccHJvZHV0b3MtZGV0YWxoZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksbUJBQW1CLEVBQUE7O0FBRnZCO0VBS0kscUJBQWEsRUFBQTs7QUFMakI7SUFPTSw0QkFBNEI7SUFDNUIseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixXQUFXO0lBQ1gsV0FBVztJQUNYLG1CQUFtQixFQUFBOztBQVp6QjtNQWNRLGFBQWE7TUFDYixXQUFXO01BQ1gsc0JBQXNCO01BQ3RCLHdCQUF3QjtNQUN4Qiw0QkFBNEI7TUFDNUIsK0JBQStCLEVBQUE7O0FBbkJ2QztNQXdCUSxjQUFjO01BQ2QsZ0JBQWdCO01BQ2hCLGtCQUFrQixFQUFBOztBQTFCMUI7TUE4QlEsNkJBQTZCO01BQzdCLGNBQWM7TUFDZCxlQUFlO01BQ2YsZ0JBQWdCO01BQ2hCLFdBQVc7TUFDWCxZQUFZLEVBQUE7O0FBbkNwQjtNQXVDUSxjQUFjO01BQ2QsZUFBZTtNQUNmLGlCQUFpQjtNQUNqQixXQUFXO01BQ1gsWUFBWSxFQUFBOztBQTNDcEI7TUErQ1EsMEJBQTBCO01BQzFCLFdBQVc7TUFDWCwyQkFBMkI7TUFDM0IsK0JBQStCO01BQy9CLGdDQUFnQyxFQUNPOztBQXBEL0M7TUF3RFEsZUFBZTtNQUNmLGNBQWM7TUFDZCxnQkFBZ0IsRUFBQTs7QUExRHhCO01BOERRLFlBQVk7TUFDWixnQkFBZ0IsRUFBQTs7QUEvRHhCO1FBaUVVLGVBQWU7UUFDZixnQkFBZ0IsRUFBQTs7QUFsRTFCO01BdUVRLCtCQUErQixFQUFBOztBQXZFdkM7TUEwRVEsZUFBZSxFQUFBOztBQTFFdkI7SUErRU0sVUFBVSxFQUFBOztBQS9FaEI7SUFrRk0sY0FBYyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcHJvZHV0b3MtZGV0YWxoZXMvcHJvZHV0b3MtZGV0YWxoZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xyXG4gIC5oZWFkZXJUb3Age1xyXG4gICAgYmFja2dyb3VuZDogI2RhZGRlMTtcclxuICB9XHJcbiAgaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZGFkZGUxO1xyXG4gICAgaW9uLWNhcmQge1xyXG4gICAgICBmb250LWZhbWlseTogXCJ1YnVudHUtbWVkaXVtXCI7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjU7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIG1hcmdpbjogMHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgICAuaW1nLWNhcmQge1xyXG4gICAgICAgIGhlaWdodDogMTUwcHg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XHJcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiB0b3AgY2VudGVyO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuZGVzY3JpY2FvIHtcclxuICAgICAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6ICM2YjZiNmI7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5hbnRlc1ZhbG9yIHtcclxuICAgICAgICB0ZXh0LWRlY29yYXRpb246IGxpbmUtdGhyb3VnaDtcclxuICAgICAgICBjb2xvcjogI2Y5MDMwMztcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDIwMDtcclxuICAgICAgICBtYXJnaW46IDBweDtcclxuICAgICAgICBwYWRkaW5nOiAwcHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5kZXNjb250b1ZhbG9yIHtcclxuICAgICAgICBjb2xvcjogIzYwMGM4MztcclxuICAgICAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudmFsb3Ige1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcInVidW50dS1ib2xkXCI7XHJcbiAgICAgICAgbWFyZ2luOiAwcHg7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG4gICAgICAgIGRpc3BsYXk6IC13ZWJraXQtYm94ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgLXdlYmtpdC1saW5lLWNsYW1wOiAxICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbCAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAubWVyY2FkbyB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGNvbG9yOiAjNDQ0OTUwO1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiA1cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlvbi1jYXJkLWhlYWRlciB7XHJcbiAgICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgICAgIG1hcmdpbjogMTBweCA1cHg7XHJcbiAgICAgICAgaW9uLWNhcmQtdGl0bGUge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlvbi1jYXJkLWNvbnRlbnQge1xyXG4gICAgICAgIHBhZGRpbmc6IDBweCA1cHggNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5jc3NDbGFzcyB7XHJcbiAgICAgIGNvbG9yOiByZWQ7XHJcbiAgICB9XHJcbiAgICAuY3NzQ2xhc3NTdGFydCB7XHJcbiAgICAgIGNvbG9yOiAjNTQwZDg4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/produtos-detalhes/produtos-detalhes.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/produtos-detalhes/produtos-detalhes.page.ts ***!
  \*******************************************************************/
/*! exports provided: ProdutosDetalhesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProdutosDetalhesPage", function() { return ProdutosDetalhesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_services_controle_produtos_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/services/controle-produtos.service */ "./src/services/controle-produtos.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var ProdutosDetalhesPage = /** @class */ (function () {
    function ProdutosDetalhesPage(controleProdutosService, navCtrl) {
        this.controleProdutosService = controleProdutosService;
        this.navCtrl = navCtrl;
    }
    ProdutosDetalhesPage.prototype.ngOnInit = function () {
        this.produtos = this.controleProdutosService.selectedProduct;
        console.log("TCL: ProdutosDetalhesPage -> ngOnInit -> this.produtos", this.produtos);
    };
    ProdutosDetalhesPage.prototype.forca = function (item) {
        this.produtos.like = !item.like;
    };
    ProdutosDetalhesPage.prototype.start = function (item) {
        this.produtos.start = !item.start;
    };
    ProdutosDetalhesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-produtos-detalhes",
            template: __webpack_require__(/*! ./produtos-detalhes.page.html */ "./src/app/pages/produtos-detalhes/produtos-detalhes.page.html"),
            styles: [__webpack_require__(/*! ./produtos-detalhes.page.scss */ "./src/app/pages/produtos-detalhes/produtos-detalhes.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_services_controle_produtos_service__WEBPACK_IMPORTED_MODULE_2__["ControleProdutosService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
    ], ProdutosDetalhesPage);
    return ProdutosDetalhesPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-produtos-detalhes-produtos-detalhes-module.js.map