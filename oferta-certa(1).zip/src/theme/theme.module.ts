import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { StorageProvider } from 'src/services/storage-provider';

//Add
const BASE_MODULES = [
	CommonModule,
	FormsModule,
	IonicModule,
	ReactiveFormsModule,
]

const PIPES = [
]

const PROVIDERS = [
	StorageProvider
]

@NgModule({
	imports: [
		...BASE_MODULES
	],
	exports: [
		...BASE_MODULES,
		...PIPES
	],
	declarations: [
		...PIPES
	],
	providers: [
		...PROVIDERS
	]
})
export class ThemeModule {}
