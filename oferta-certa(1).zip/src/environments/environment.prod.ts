export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyC7dF_kQwedt-g6UsY4pCYguEtOEXefLKY",
    authDomain: "fir-login-5643f.firebaseapp.com",
    databaseURL: "https://fir-login-5643f.firebaseio.com",
    projectId: "fir-login-5643f",
    storageBucket: "fir-login-5643f.appspot.com",
    messagingSenderId: "800283849432"
  }
};
