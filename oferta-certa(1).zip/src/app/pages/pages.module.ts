import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { Routes, RouterModule } from "@angular/router";

import { IonicModule } from "@ionic/angular";

import { PagesPage } from "./pages.page";
import { HomePageModule } from "./home/home.module";
import { PerfilPageModule } from "./perfil/perfil.module";
import { ThemeModule } from "src/theme/theme.module";

const routes: Routes = [
	{
		path: "",
		component: PagesPage,
		children: [
			{ path: "", loadChildren: "./home/home.module#HomePageModule" },
			{
				path: "home",
				loadChildren: "./home/home.module#HomePageModule"
			},
			{
				path: "notificacoes",
				loadChildren:
					"../notificacoes/notificacoes.module#NotificacoesPageModule"
			},
			{ path: "menu", loadChildren: "../menu/menu.module#MenuPageModule" },
			{ path: "**", redirectTo: "home", pathMatch: "full" }
		]
	},
	{
		path: "",
		redirectTo: "pages"
	}
];

@NgModule({
	imports: [ThemeModule, RouterModule.forChild(routes)],
	declarations: [PagesPage]
})
export class PagesPageModule {}
