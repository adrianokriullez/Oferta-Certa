import { Component, OnInit, ViewChild } from "@angular/core";
import { MenuController } from "@ionic/angular";
import { NavController } from "@ionic/angular";
import { IonTabs } from "@ionic/angular";

@Component({
	selector: "app-pages",
	templateUrl: "./pages.page.html",
	styleUrls: ["./pages.page.scss"]
})
export class PagesPage implements OnInit {
	@ViewChild("app_tabs") tabRef: IonTabs;
	constructor(
		private menu: MenuController,
		private navigation: NavController
	) {}

	ngOnInit() {
		// this.tabRef.select("home");
		this.tabRef.select("home");
	}
}
