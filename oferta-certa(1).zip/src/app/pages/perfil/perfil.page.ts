import { Component, OnInit } from '@angular/core';
import { StorageProvider } from 'src/services/storage-provider';
import { LoadingController, AlertController, NavController } from '@ionic/angular';
import { AngularFireAuth } from '@angular/fire/auth';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
})
export class PerfilPage implements OnInit {
  //var formulario reativo
	public loginForm: FormGroup;

	//submit do form
	public submitted: boolean = false;

	//Mostra a senha do inout
	public iconeye = "eye";

	//type do campo de senha
	public password = "password";

	constructor(
		public formbuilder: FormBuilder,
		public afAuth: AngularFireAuth,
		private navigation: NavController,
		public alertController: AlertController,
		public loading: LoadingController,
		private storage: StorageProvider
	) {
		this.loginForm = this.formbuilder.group({
			email: [null, [Validators.required, Validators.email]],
			password: ''
		});

	}

	ngOnInit() {
		this.buscaDados();
	}

	public async buscaDados(){
		let retorno = await this.storage.getItem("user");
      this.loginForm.setValue({
			email: retorno.email || '',
			password:'',
		})
	}
	//Login
	public async submitLogin() {
		this.submitted = true;

		if (this.loginForm.valid) {

			const userInfo: object = {
				email: this.loginForm.value.email
			};
            await this.storage.setItem("user", userInfo);

            const alert: any = await this.alertController.create({
				message: 'Dados salvos!',
				buttons: ['Ok']
			});

			alert.present();
			//finaliza o loading

			this.submitted = false;
        }else {
			const alert: any = await this.alertController.create({
				subHeader: 'Atenção',
				message: 'Verifique os dados',
				buttons: ['Ok']
			});

			alert.present();
		}
    }

	//Mostra senha para o usuário
	public eyeTroca(event) {
		if (event.target.name == "eye") {
			this.iconeye = "eye-off";
			this.password = "text";
		} else {
			this.iconeye = "eye";
			this.password = "password";
		}
	}

	//Alert para mensagens
	async showAlert(title: string, msg: string, btn: string) {
		const alert = await this.alertController.create({
			subHeader: title,
			message: msg,
			buttons: [btn]
		});
		await alert.present();
	}

}
