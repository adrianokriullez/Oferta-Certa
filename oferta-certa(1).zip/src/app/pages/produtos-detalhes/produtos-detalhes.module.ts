import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ProdutosDetalhesPage } from './produtos-detalhes.page';

const routes: Routes = [
  {
    path: '',
    component: ProdutosDetalhesPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ProdutosDetalhesPage]
})
export class ProdutosDetalhesPageModule {}
