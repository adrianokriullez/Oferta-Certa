import { Component, OnInit } from "@angular/core";
import { ControleProdutosService } from "src/services/controle-produtos.service";
import { NavController } from "@ionic/angular";

@Component({
	selector: "app-produtos-detalhes",
	templateUrl: "./produtos-detalhes.page.html",
	styleUrls: ["./produtos-detalhes.page.scss"]
})
export class ProdutosDetalhesPage implements OnInit {
	public produtos: any;

	constructor(
		public controleProdutosService: ControleProdutosService,
		private navCtrl: NavController
	) {}

	ngOnInit() {
		this.produtos = this.controleProdutosService.selectedProduct;
		console.log(
			"TCL: ProdutosDetalhesPage -> ngOnInit -> this.produtos",
			this.produtos
		);
	}

	public forca(item) {
		this.produtos.like = !item.like;
	}

	public start(item) {
		this.produtos.start = !item.start;
	}
}
