import { Component } from "@angular/core";
//Firebase
import { AngularFireAuth } from "@angular/fire/auth";
import * as firebase from "firebase/app";
import "firebase/firestore";
import { StorageProvider } from "src/services/storage-provider";
import { ControleProdutosService } from "src/services/controle-produtos.service";
import { NavController } from "@ionic/angular";

@Component({
	selector: "app-home",
	templateUrl: "home.page.html",
	styleUrls: ["home.page.scss"]
})
export class HomePage {
	public retorno: any;
	public image = "/assets/images/default-image.png";

	public produtos = [
		{
			descricao: "Kit 12 Mini Biscoito Arroz Integral Chia Linhaça Camil 150g",
			valor: "R$150,00",
			desconto: "R$117,00",
			img: "https://www.extra-imagens.com.br/Alimentos/alimentosbasicos/arroz/14428677/1064540006/kit-12-mini-biscoito-arroz-integral-chia-linhaca-camil-150g-14428677.jpg",
			mercado: "Teixeira Supermercados",
			km: "5km",
			like: false,
			start: false
		},
		{
			descricao: "Fralda Pampers Confort Sec Super XG - 174 Unidades",
			valor: "R$191,70",
			desconto: "R$164,70",
			img: "https://www.extra-imagens.com.br/bebes/TrocadoBebe/FraldasDescartaveisparaBebes/1000069015/1012436201/fralda-pampers-confort-sec-super-xg-174-unidades-1000069015.jpg",
			mercado: "Colina Supermercados",
			km: "5km",
			like: false,
			start: false
		},
		{
			descricao: "Café Melitta a Vácuo Tradicional 500grs - Melitta",
			valor: "R$11,55",
			desconto: "R$7,99",
			img: "https://www.extra-imagens.com.br/Alimentos/Matinais/cafes/15093509/1120303447/cafe-melitta-a-vacuo-tradicional-500grs-melitta-15093509.jpg",
			mercado: "Chimar Supermercados",
			km: "5km",
			like: false,
			start: false
		},
		{
			descricao: "Café Pilão Almofada 500 Gramas",
			valor: "R$8,99",
			desconto: "R$5,99",
			img: "https://www.extra-imagens.com.br/Alimentos/Matinais/cafes/6574328/284144054/Cafe-Pilao-Almofada-500-Gramas-6574328.jpg",
			mercado: "Olidel Supermercados",
			km: "5km",
			like: false,
			start: false
		},
		{
			descricao: "Shampoo Pantene Força e Reconstrução 400ml",
			valor: "R$16,98",
			desconto: "R$95,99",
			img: "https://www.extra-imagens.com.br/perfumaria/produtosparacabelos/ShampoosparaCabelos/13776997/1203192835/shampoo-pantene-forca-e-reconstrucao-400ml-13776997.jpg",
			mercado: "Olidel Supermercados",
			km: "5km",
			like: false,
			start: false
		},
		{
			descricao: "Cerveja Budweiser Pilsen 330ml",
			valor: "R$ 2,58",
			desconto: "R$ 2,19",
			img: "https://i.promobit.com.br/855314610315603013367512294537.png",
			mercado: "Chimar Supermercados",
			km: "5km",
			like: false,
			start: false
		},
		{
			descricao:
				'Smartphone Samsung Galaxy A10 32GB Dual Chip 2GB RAM Tela 6.2"',
			valor: "R$ 999,00 ",
			desconto: "R$ 679,03",
			img: "https://i.promobit.com.br/664802533015602865658695206277.jpg",
			mercado: "Supermercado Colina",
			km: "15km",
			like: false,
			start: false
		},
		{
			descricao:
				"Caixa Organizadora com Tampa em MDF 2 Peças Rosa e Vermelho Zippy Toys 6173",
			valor: "R$ 89,90",
			desconto: "R$ 39,90",
			img: "https://i.promobit.com.br/756388451415602998232595347394.jpg",
			mercado: "Chimar Supermercados",
			km: "16km",
			like: false,
			start: false
		},
		{
			descricao:
				'Smartphone Motorola Moto G7 Power 32GB Dual Chip 3GB RAM Tela 6.2"',
			valor: "R$ 999,00",
			desconto: "R$ 849,15",
			img:
				"https://i.promobit.com.br/smartphone_motorola_moto_g7_power_32gb.jpg",
			mercado: "Supermercado Colina",
			km: "14km",
			like: false,
			start: false
		}
	];
	constructor(
		private navCtrl: NavController,
		private storage: StorageProvider,
		public controleProdutosService: ControleProdutosService
	) {
		this.retorno = this.storage.getItem("user");
	}

	ngOnInit() {}

	//Detalhes do produto
	public openDetail(event) {
		//Passa o produto para o service de detalhes do produto
		this.controleProdutosService.selectedProduct = event;
		//Redireciona para página de produtos
		this.navCtrl.navigateForward("/produtos-detalhes", {
			animated: true
		});
	}

	public forca(item) {
		item.like = !item.like;
		this.produtos.indexOf(item);
	}

	public start(item) {
		item.start = !item.start;
		this.produtos.indexOf(item);
	}
}
