import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { NavController } from "@ionic/angular";
//Firebase
import { AngularFireAuth } from "@angular/fire/auth";
import * as firebase from "firebase/app";
import "firebase/firestore";

import { LoadingController } from "@ionic/angular";
import { AlertController } from "@ionic/angular";
import { StorageProvider } from "src/services/storage-provider";

@Component({
	selector: "app-cadastro",
	templateUrl: "./cadastro.page.html",
	styleUrls: ["./cadastro.page.scss"]
})
export class CadastroPage implements OnInit {
	private db: firebase.firestore.Firestore = firebase.firestore();

	//var formulario reativo
	public registerOne: FormGroup;

	//Mostra a senha do inout
	public iconeye = "eye";

	//type do campo de senha
	public password = "password";

	//submit do form
	public submitted: boolean = false;

	constructor(
		public formbuilder: FormBuilder,
		private navigation: NavController,
		public alertController: AlertController,
		public loading: LoadingController,
		public afAuth: AngularFireAuth,
		private storage: StorageProvider
	) {
		this.registerOne = this.formbuilder.group({
			email: [null, [Validators.required, Validators.email]],
			password: [null, [Validators.required, Validators.minLength(6)]],
			confirmpassword: [null, [Validators.required, Validators.minLength(6)]]
		});
	}

	ngOnInit() {}

	public submitRegisterOne() {
		this.submitted = true;
		if (this.registerOne.valid) {
			if (
				this.registerOne.value.password ===
				this.registerOne.value.confirmpassword
			) {
				this.loading.create({ message: "Aguarde..." }).then(_loading => {
					_loading.present();
				});

				this.afAuth.auth
					.createUserWithEmailAndPassword(
						this.registerOne.value.email,
						this.registerOne.value.password
					)
					.then(_user => {
						const userInfo: object = {
							id: this.afAuth.auth.currentUser.uid,
							email: this.registerOne.value.email,
							date: firebase.firestore.FieldValue.serverTimestamp()
						};

						this.storage.setItem("user", userInfo);
						console.log(
							"TCL: CadastroPage -> submitRegisterOne -> userInfo",
							userInfo
						);

						//Enviar o usuário para próxima página
						this.navigation.navigateForward("/pages", {
							animated: true
						});

						//finaliza o loading
						this.loading.dismiss();

						this.submitted = false;
					})
					.catch(error => {
						if (error.code == "auth/email-already-in-use") {
							this.showAlert(
								"Erro ao cadastrar",
								"O endereço de e-mail já está sendo usado por outra conta",
								"Voltar"
							);

							//finaliza o loading
							this.loading.dismiss();

							this.submitted = false;
						} else {
							//Mensagem de Erro padrão caso não encontre o erro de firesabe
							this.showAlert(
								"Erro ao cadastrar",
								"Não foi possível realizar seu cadastro",
								"Voltar"
							);

							//finaliza o loading
							this.loading.dismiss();

							this.submitted = false;
						}
					});
			}
		}
	}

	//Mostra senha para o usuário
	public eyeTroca(event) {
		if (event.target.name == "eye") {
			this.iconeye = "eye-off";
			this.password = "text";
		} else {
			this.iconeye = "eye";
			this.password = "password";
		}
	}

	//Alert para mensagens
	async showAlert(title: string, msg: string, btn: string) {
		const alert = await this.alertController.create({
			subHeader: title,
			message: msg,
			buttons: [btn]
		});
		await alert.present();
	}
}
