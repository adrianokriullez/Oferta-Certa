import { NgModule } from "@angular/core";
import { PreloadAllModules, RouterModule, Routes } from "@angular/router";

const routes: Routes = [
	{ path: "", redirectTo: "start", pathMatch: "full" },
	{ path: "start", loadChildren: "./start/start.module#StartPageModule" },
	{ path: "login", loadChildren: "./login/login.module#LoginPageModule" },
	{
		path: "cadastro",
		loadChildren: "./cadastro/cadastro.module#CadastroPageModule"
	},
	{ path: "pages", loadChildren: "./pages/pages.module#PagesPageModule" },
	{ path: 'perfil', loadChildren: './pages/perfil/perfil.module#PerfilPageModule' },
	{ path: 'home', loadChildren: './pages/home/home.module#HomePageModule' },
  { path: 'produtos-detalhes', loadChildren: './pages/produtos-detalhes/produtos-detalhes.module#ProdutosDetalhesPageModule' },
  { path: 'notificacoes', loadChildren: './notificacoes/notificacoes.module#NotificacoesPageModule' },
  { path: 'menu', loadChildren: './menu/menu.module#MenuPageModule' }
];

@NgModule({
	imports: [
		RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
	],
	exports: [RouterModule]
})
export class AppRoutingModule {}
