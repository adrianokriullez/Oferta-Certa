import { Component } from "@angular/core";

import { Platform } from "@ionic/angular";
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { AngularFireAuth } from "@angular/fire/auth";
import { StorageProvider } from "src/services/storage-provider";
import { NavController } from "@ionic/angular";
import { HomePage } from "./pages/home/home.page";
import { MenuController } from "@ionic/angular";

@Component({
	selector: "app-root",
	templateUrl: "app.component.html"
})
export class AppComponent {
	public pages = [
		{
			url: "home",
			icon: "home",
			title: "home"
		},
		{
			url: "perfil",
			icon: "contacts",
			title: "Perfil"
		}
	];
	constructor(
		private platform: Platform,
		private splashScreen: SplashScreen,
		private statusBar: StatusBar,
		private firebaseAuth: AngularFireAuth,
		private storage: StorageProvider,
		private navigation: NavController,
		private menu: MenuController
	) {
		this.initializeApp();
	}

	initializeApp() {
		this.platform.ready().then(() => {
			this.statusBar.styleDefault();
			this.splashScreen.hide();
		});
	}

	public open(url) {
		console.log("TCL: AppComponent -> open -> url", url);
		this.navigation.navigateRoot(url, { animated: true });
	}

	public logout() {
		this.firebaseAuth.auth.signOut();
		this.storage.setItem("user", null);
		this.navigation.navigateRoot("/start");
	}

	public closeMenu() {
		this.menu.close();
	}
}
