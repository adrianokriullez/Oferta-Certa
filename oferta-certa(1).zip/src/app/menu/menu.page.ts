import { Component, OnInit } from "@angular/core";
import { StorageProvider } from "src/services/storage-provider";
import { AngularFireAuth } from "@angular/fire/auth";
import { NavController } from "@ionic/angular";

@Component({
	selector: "app-menu",
	templateUrl: "./menu.page.html",
	styleUrls: ["./menu.page.scss"]
})
export class MenuPage implements OnInit {
	constructor(
		private firebaseAuth: AngularFireAuth,
		private storage: StorageProvider,
		private navigation: NavController
	) {}

	ngOnInit() {}

	public logout() {
		this.firebaseAuth.auth.signOut();
		this.storage.setItem("user", null);
		this.navigation.navigateRoot("/start");
	}

	public perfil() {
		this.navigation.navigateForward("perfil", { animated: true });
	}
}
