import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { NavController } from "@ionic/angular";
import { LoadingController } from "@ionic/angular";
import { AlertController } from "@ionic/angular";

//Firebase
import { AngularFireAuth } from "@angular/fire/auth";

import { StorageProvider } from "src/services/storage-provider";

@Component({
	selector: "app-login",
	templateUrl: "./login.page.html",
	styleUrls: ["./login.page.scss"]
})
export class LoginPage implements OnInit {
	//var formulario reativo
	public loginForm: FormGroup;

	//submit do form
	public submitted: boolean = false;

	//Mostra a senha do inout
	public iconeye = "eye";

	//type do campo de senha
	public password = "password";

	constructor(
		public formbuilder: FormBuilder,
		public afAuth: AngularFireAuth,
		private navigation: NavController,
		public alertController: AlertController,
		public loading: LoadingController,
		private storage: StorageProvider
	) {
		this.loginForm = this.formbuilder.group({
			email: [null, [Validators.required, Validators.email]],
			password: [null, [Validators.required, Validators.minLength(6)]]
		});
	}

	ngOnInit() {}

	//Login
	submitLogin() {
		this.submitted = true;

		if (this.loginForm.valid) {
			this.loading.create({ message: "Aguarde..." }).then(_loading => {
				_loading.present();
			});

			this.afAuth.auth
				.signInWithEmailAndPassword(
					this.loginForm.value.email,
					this.loginForm.value.password
				)
				.then(_response => {
					const userInfo: object = {
						id: _response.user.uid,
						email: _response.user.email
					};

					this.storage.setItem("user", userInfo);
					console.log(
						"TCL: LoginPage -> submitLogin -> _response",
						_response
					);
					//Enviar o usuário para próxima página
					this.navigation.navigateRoot("/pages", { animated: true });
					//finaliza o loading
					this.loading.dismiss();
					this.submitted = false;
				})
				.catch(error => {
					if (error.code == "auth/wrong-password") {
						this.showAlert("Erro ao logar", "Senha incorreta", "Voltar");
						this.loginForm.controls["password"].setValue(null);
						//finaliza o loading
						this.loading.dismiss();
						this.submitted = false;
					} else {
						this.showAlert(
							"Erro ao logar",
							"Não foi possivel realizar seu login",
							"Voltar"
						);
						this.loginForm.controls["password"].setValue(null);
						//finaliza o loading
						this.loading.dismiss();
						this.submitted = false;
					}
				});
		}
	}

	//Mostra senha para o usuário
	public eyeTroca(event) {
		if (event.target.name == "eye") {
			this.iconeye = "eye-off";
			this.password = "text";
		} else {
			this.iconeye = "eye";
			this.password = "password";
		}
	}

	//Alert para mensagens
	async showAlert(title: string, msg: string, btn: string) {
		const alert = await this.alertController.create({
			subHeader: title,
			message: msg,
			buttons: [btn]
		});
		await alert.present();
	}
}
