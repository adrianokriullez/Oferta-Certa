import { Component, OnInit } from "@angular/core";
import { NavController } from "@ionic/angular";
import { StorageProvider } from "src/services/storage-provider";

@Component({
	selector: "app-start",
	templateUrl: "./start.page.html",
	styleUrls: ["./start.page.scss"]
})
export class StartPage implements OnInit {
	// Optional parameters to pass to the swiper instance. See http://idangero.us/swiper/api/ for valid options.
	public slideOpts = {
		initialSlide: 0,
		speed: 400
	};
	constructor(
		private navigation: NavController,
		private storage: StorageProvider
	) {}

	ngOnInit() {
		if (!this.storage.getItem("user")) {
			this.navigation.navigateRoot("/start", { animated: true });
		} else {
			this.navigation.navigateRoot("/pages", { animated: true });
		}
	}

	public cadastro() {
		//Enviar o usuário para próxima página
		this.navigation.navigateForward("/cadastro", { animated: true });
	}

	public login() {
		//Enviar o usuário para próxima página
		this.navigation.navigateForward("/login", { animated: true });
	}
}
