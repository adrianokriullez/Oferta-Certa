import { Injectable } from "@angular/core";
import { NavController } from "@ionic/angular";

@Injectable({
	providedIn: "root"
})
export class ControleProdutosService {
	public selectedProduct: object;
	public selectedFilter: object;
	private __textFilter: string;
	constructor(private navCtrl: NavController) {}
}
