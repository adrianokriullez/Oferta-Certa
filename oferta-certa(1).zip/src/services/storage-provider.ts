import { Injectable } from "@angular/core";

@Injectable()
export class StorageProvider {
	constructor() {}

	// Get item in localStorage
	public getItem(key: string): any {
		if (!key) {
			return null;
		} else {
			return JSON.parse(localStorage.getItem(key));
		}
	}

	// Set item in localStorage
	public setItem(key: string, value: any): void {
		localStorage.setItem(key, JSON.stringify(value));
	}

	// Clear
	public clear(): void {
		return localStorage.clear();
	}
}
